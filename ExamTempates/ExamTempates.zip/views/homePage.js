import {html} from '../node_modules/lit-html/lit-html.js'




const homeTemplate = () => html ``


export function showHomePage(ctx) {
   
    ctx.render(homeTemplate())
}


const homeSection = document.getElementById('home')



 export function showHome (ctx) {
    ctx.showTargetSection(homeSection)

}